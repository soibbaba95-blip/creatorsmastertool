// ===== TOOL API FUNCTIONS =====

// Keyword difficulty mock
export function keywordScore(keyword){
let len = keyword.length;
if(len < 5) return "High Competition";
if(len < 10) return "Medium Competition";
return "Low Competition";
}

// SEO title builder
export function buildTitle(keyword){
return `Best ${keyword} Guide 2026 | Complete Tutorial`;
}

// Social tags builder
export function socialTags(keyword){
return [
"#"+keyword,
"#viral",
"#trending",
"#creator",
"#growth"
];
}

// earnings calculator
export function calcAdsense(views, rpm){
return (views/1000)*rpm;
}